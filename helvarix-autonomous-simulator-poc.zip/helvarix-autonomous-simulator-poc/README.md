# Helvarix Autonomous Simulator — Proof of Concept

This TypeScript prototype demonstrates a minimal autonomy-validation workflow:
- procedural terrain generation
- hazard placement
- A* pathfinding
- rover traversal
- mission metrics output

## Run locally
```bash
npm install
npm run dev
```

## What this proves
This is **not** a full autonomy platform. It is a compact proof of concept showing that Helvarix Systems LLC can produce:
- a terrain simulation environment
- path planning logic
- mission metrics
- a visual demonstrator suitable for early proposal support
